Участник 1 — ядро и SQLite

Коммит: feat(core): strengthen portfolio, analytics and SQLite domain layer

Содержимое: доменные расчёты, FX-оценка, правила алертов, аналитика и SQLite persistence с модульными тестами. Не менять HTML/renderer и внешние API-адаптеры.

Проверка из корня общего репозитория: npm test (или запустить перечисленные тесты через node --test).
